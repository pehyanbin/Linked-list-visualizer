# Linked List Visualizer

Interactive React website for visualizing linked-list concepts, operations, iterators, smart pointers, and the List ADT.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy to Wasmer

```bash
npm install
npm run build
wasmer login
wasmer deploy
```

The `wasmer.toml` maps the Vite `dist` folder to Wasmer's static web server.
