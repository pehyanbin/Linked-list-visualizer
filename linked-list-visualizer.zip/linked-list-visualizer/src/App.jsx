import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Boxes,
  ChevronsLeft,
  ChevronsRight,
  Clock3,
  GitBranch,
  Plus,
  RotateCcw,
  Search,
  ShieldCheck,
  Trash2,
} from "lucide-react";

const initialList = ["7", "6", "5"];

const codeSnippets = {
  construct: `p = new SinglyLinkedList(5);
q = new SinglyLinkedList(7, p);`,
  access: `int a = p->data;
int b = q->next->data;`,
  insertAfter: `r = new SinglyLinkedList(6);
r->next = p;
q->next = r;`,
  deleteAfter: `q->next = q->next->next;`,
  pushBack: `while (*pInsert != nullptr) {
  pInsert = &((*pInsert)->next);
}
*pInsert = new SinglyLinkedList(9);`,
};

function Button({ children, onClick, variant = "default" }) {
  const className =
    variant === "primary"
      ? "button primary"
      : variant === "secondary"
        ? "button secondary"
        : variant === "danger"
          ? "button danger"
          : "button";

  return (
    <button className={className} onClick={onClick} type="button">
      {children}
    </button>
  );
}

function Card({ children }) {
  return <section className="card"><div className="card-content">{children}</div></section>;
}

function NodeBox({ value, active, label, prev }) {
  return (
    <motion.div
      layout
      initial={{ scale: 0.92, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.88, opacity: 0 }}
      className={`node ${active ? "active" : ""}`}
    >
      {label && <div className="node-label">{label}</div>}
      {prev && <div className="node-prev">prev</div>}
      <div className="node-data">{value}</div>
      <div className="node-next">next</div>
    </motion.div>
  );
}

function Arrow({ nil = false }) {
  return (
    <div className="arrow">
      {nil ? <span className="nil">Nil</span> : <ArrowRight size={24} />}
    </div>
  );
}

function LinkedListView({ list, activeIndex, mode = "singly", labelHead = "head", labelTail = "tail" }) {
  return (
    <div className="list-scroll">
      <div className="list-line">
        <div className="pointer-label">{labelHead}</div>
        <Arrow />
        <AnimatePresence mode="popLayout">
          {list.map((value, index) => (
            <React.Fragment key={`${value}-${index}`}>
              <NodeBox
                value={value}
                active={index === activeIndex}
                label={index === list.length - 1 ? labelTail : undefined}
                prev={mode === "doubly"}
              />
              <Arrow nil={index === list.length - 1} />
            </React.Fragment>
          ))}
        </AnimatePresence>
      </div>
      {mode === "doubly" && list.length > 1 && (
        <div className="backward-note">
          <ArrowLeft size={16} /> previous links allow backward traversal and make end deletion easier
        </div>
      )}
    </div>
  );
}

function ConceptMap() {
  const [query, setQuery] = useState("");

  const concepts = [
    ["Array relocation", "Insertion/deletion shifts elements, O(n)."],
    ["Singly linked list", "Data plus next pointer; forward traversal only."],
    ["Nil / nullptr", "Marks the end of the list."],
    ["Insert node", "Create a node, point it to successor, redirect predecessor."],
    ["Delete node", "Bypass the node by changing next."],
    ["Push front", "New node points to old head."],
    ["Push back", "Find Nil or maintain tail pointer."],
    ["Smart pointers", "RAII-friendly ownership instead of raw new/delete."],
    ["Factory method", "makeNode forwards constructor arguments to make_shared."],
    ["Singly iterator", "Dereference, ++, equality, begin/end."],
    ["Doubly linked list", "next and previous links enable bidirectional traversal."],
    ["Iterator DFA", "BEFORE, DATA, AFTER states with ++ and -- actions."],
    ["List ADT", "push, remove, indexing, iteration, copy/move."],
  ];

  const filtered = concepts.filter(([title, desc]) =>
    `${title} ${desc}`.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <Card>
      <div className="row-between">
        <div>
          <h2>Slide concept map</h2>
          <p className="small-muted">Search the major ideas and connect them to the demos.</p>
        </div>
        <div className="top-search">
          <Search className="search-icon" size={16} />
          <input
            className="input search"
            placeholder="Search concepts..."
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
      </div>
      <div className="concept-grid">
        {filtered.map(([title, desc]) => (
          <motion.div layout className="concept-card" key={title}>
            <strong>{title}</strong>
            <p className="small-muted">{desc}</p>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}

function ArrayRelocationDemo() {
  const [deleted, setDeleted] = useState(false);
  const before = ["3", "5", "29", "20", "4", "", ""];
  const after = ["3", "29", "20", "4", "", "", ""];

  return (
    <Card>
      <div className="row-between">
        <div>
          <h2>Why linked lists?</h2>
          <p className="small-muted">Arrays store elements contiguously, so insertion and deletion often require shifting items.</p>
        </div>
        <Button onClick={() => setDeleted(!deleted)} variant="secondary">
          {deleted ? "Reset" : "Delete 5"}
        </Button>
      </div>
      <div className="array-row">
        {(deleted ? after : before).map((value, index) => (
          <motion.div
            layout
            className={`array-cell ${value === "" ? "empty" : ""} ${value === "5" ? "delete" : ""}`}
            key={index}
          >
            {value}
          </motion.div>
        ))}
      </div>
      <p className="small-muted">Average insertion/deletion in an array takes O(n) time because roughly n/2 elements move.</p>
    </Card>
  );
}

function OperationPlayground() {
  const [list, setList] = useState(initialList);
  const [value, setValue] = useState("9");
  const [activeIndex, setActiveIndex] = useState(0);
  const [log, setLog] = useState("Start with q → 7 → 6 → 5 → Nil");
  const [snippet, setSnippet] = useState(codeSnippets.construct);

  const safeValue = value.trim() || "X";

  const pushFront = () => {
    setList([safeValue, ...list]);
    setActiveIndex(0);
    setLog(`Inserted ${safeValue} at the top: new node points to the old head.`);
    setSnippet(`head = new Node(${safeValue}, head);`);
  };

  const pushBack = () => {
    setList([...list, safeValue]);
    setActiveIndex(list.length);
    setLog(`Inserted ${safeValue} at the end after searching for Nil.`);
    setSnippet(codeSnippets.pushBack);
  };

  const insertAfterActive = () => {
    const next = [...list];
    next.splice(activeIndex + 1, 0, safeValue);
    setList(next);
    setActiveIndex(activeIndex + 1);
    setLog(`Inserted ${safeValue} after the current node by redirecting next pointers.`);
    setSnippet(codeSnippets.insertAfter);
  };

  const deleteAfterActive = () => {
    if (activeIndex >= list.length - 1) {
      setLog("Nothing to delete after the current node because next is Nil.");
      setSnippet(codeSnippets.deleteAfter);
      return;
    }

    const deleted = list[activeIndex + 1];
    const next = [...list];
    next.splice(activeIndex + 1, 1);
    setList(next);
    setLog(`Deleted node ${deleted} after the current node: current.next skips over it.`);
    setSnippet(codeSnippets.deleteAfter);
  };

  const reset = () => {
    setList(initialList);
    setActiveIndex(0);
    setLog("Start with q → 7 → 6 → 5 → Nil");
    setSnippet(codeSnippets.construct);
  };

  return (
    <Card>
      <div className="row-between">
        <div>
          <div className="section-heading">
            <GitBranch className="section-icon" />
            <h2>Singly linked list operations</h2>
          </div>
          <p className="small-muted">Each node stores data and one next pointer. The list ends at Nil, represented in C++ as nullptr or a sentinel object.</p>
        </div>
        <div className="controls">
          <input className="input" value={value} onChange={(event) => setValue(event.target.value)} />
          <Button onClick={pushFront} variant="primary"><Plus size={16} /> Push front</Button>
          <Button onClick={pushBack} variant="secondary"><Plus size={16} /> Push back</Button>
          <Button onClick={insertAfterActive} variant="secondary">Insert after</Button>
          <Button onClick={deleteAfterActive} variant="danger"><Trash2 size={16} /> Delete after</Button>
          <Button onClick={reset}><RotateCcw size={16} /> Reset</Button>
        </div>
      </div>

      <LinkedListView list={list} activeIndex={activeIndex} />

      <div className="controls">
        {list.map((item, index) => (
          <Button
            key={`${item}-${index}`}
            variant={index === activeIndex ? "primary" : "default"}
            onClick={() => {
              setActiveIndex(index);
              setLog(`Current node is ${item}. Access data with pointer->data; move with pointer->next.`);
              setSnippet(codeSnippets.access);
            }}
          >
            current = {item}
          </Button>
        ))}
      </div>

      <div className="two-col" style={{ marginTop: 18 }}>
        <div className="trace-box">
          <strong>Action trace</strong>
          <p className="small-muted">{log}</p>
        </div>
        <pre><code>{snippet}</code></pre>
      </div>
    </Card>
  );
}

function SmartPointersPanel() {
  const cards = [
    { icon: ShieldCheck, title: "RAII", text: "Give heap resources to stack objects whose destructors release them automatically." },
    { icon: Boxes, title: "unique_ptr", text: "Exactly one owner. Default choice for plain objects when sharing is not needed." },
    { icon: Boxes, title: "shared_ptr", text: "Reference-counted ownership. Useful when multiple owners share one node chain." },
    { icon: Boxes, title: "weak_ptr", text: "Non-owning observer. Breaks shared_ptr cycles in doubly linked structures." },
  ];

  return (
    <div className="info-grid">
      {cards.map(({ icon: Icon, title, text }) => (
        <div className="info-card" key={title}>
          <Icon size={26} />
          <h3>{title}</h3>
          <p className="small-muted">{text}</p>
        </div>
      ))}
    </div>
  );
}

function StatePill({ name, active }) {
  return <div className={`state-pill ${active ? "active" : ""}`}>{name}</div>;
}

function IteratorDFA() {
  const [state, setState] = useState("INIT");
  const [position, setPosition] = useState(-1);
  const data = ["A", "B", "C"];

  const forward = () => {
    if (state === "INIT" || state === "BEFORE") {
      setState(data.length ? "DATA" : "AFTER");
      setPosition(0);
    } else if (state === "DATA") {
      if (position + 1 >= data.length) {
        setState("AFTER");
        setPosition(data.length);
      } else {
        setPosition(position + 1);
      }
    }
  };

  const backward = () => {
    if (state === "INIT" || state === "AFTER") {
      setState(data.length ? "DATA" : "BEFORE");
      setPosition(data.length - 1);
    } else if (state === "DATA") {
      if (position - 1 < 0) {
        setState("BEFORE");
        setPosition(-1);
      } else {
        setPosition(position - 1);
      }
    }
  };

  const reset = () => {
    setState("INIT");
    setPosition(-1);
  };

  return (
    <Card>
      <div className="section-heading">
        <Clock3 className="section-icon" />
        <h2>Iterator state transitions</h2>
      </div>
      <p className="small-muted">
        A doubly linked-list iterator can move like a small deterministic finite automaton: BEFORE, DATA, and AFTER. ++ follows next; -- follows previous.
      </p>

      <div className="state-grid">
        <div className="state-panel">
          <div className="state-top">
            <span className="small-muted"><strong>State machine</strong></span>
            <span className="badge" style={{ margin: 0 }}>{state}</span>
          </div>

          <div className="state-machine">
            <div className="state-before"><StatePill name="BEFORE" active={state === "BEFORE"} /></div>
            <div className="state-data"><StatePill name="DATA" active={state === "DATA"} /></div>
            <div className="state-after"><StatePill name="AFTER" active={state === "AFTER"} /></div>

            <div className="dash-one" />
            <div className="dash-two" />
            <div className="state-tag one">++ / --</div>
            <div className="state-tag two">Nil check</div>
            <div className="state-tag three">INIT</div>
          </div>

          <div className="state-explain">
            <div><strong>BEFORE</strong><br />Iterator is before the head.</div>
            <div><strong>AFTER</strong><br />Iterator is after the tail.</div>
            <div className="wide"><strong>DATA</strong><br />Iterator points to a real node and can be dereferenced.</div>
          </div>
        </div>

        <div>
          <LinkedListView list={data} activeIndex={state === "DATA" ? position : undefined} mode="doubly" />
          <div className="controls">
            <Button onClick={backward} variant="secondary"><ChevronsLeft size={16} /> operator--</Button>
            <Button onClick={forward} variant="primary"><ChevronsRight size={16} /> operator++</Button>
            <Button onClick={reset}>Reset iterator</Button>
          </div>
          <p className="small-muted">
            Current state: <strong>{state}</strong>
            {state === "DATA" ? ` at node ${data[position]}` : " at a boundary"}
          </p>
        </div>
      </div>
    </Card>
  );
}

function ListADTPanel() {
  const ops = ["push_front", "push_back", "remove", "operator[]", "begin/end", "rbegin/rend", "copy", "move", "swap", "size"];

  return (
    <Card>
      <h2>List ADT checklist</h2>
      <p className="small-muted">
        The final abstraction wraps the node structure behind a List class with endpoints, size, copy/move semantics, and iterator methods.
      </p>
      <div className="adt-tags">
        {ops.map((operation) => <span className="adt-tag" key={operation}>{operation}</span>)}
      </div>
      <div className="warning">
        <strong>Destructor note:</strong> a custom destructor can walk backward from the tail to avoid deep recursive destruction through next links on large lists.
      </div>
    </Card>
  );
}

export default function App() {
  return (
    <main className="page">
      <header className="container hero">
        <span className="badge">COS30008 • Linked Lists</span>
        <div className="hero-grid">
          <div>
            <h1>Linked List Visualizer</h1>
            <p>
              Explore why arrays relocate data, how singly and doubly linked lists connect nodes, how insertion/deletion changes pointers, and how iterators move through states.
            </p>
          </div>
          <div className="card">
            <LinkedListView list={["CCCC", "BBBB", "AAAA"]} activeIndex={0} />
          </div>
        </div>
      </header>

      <div className="container stack">
        <ConceptMap />
        <ArrayRelocationDemo />
        <OperationPlayground />
        <SmartPointersPanel />
        <IteratorDFA />
        <ListADTPanel />
      </div>
    </main>
  );
}
